/* CodeCart PRO Bootstrap 3 → Bootstrap 5 compatibility experimental v0.2.1. MIT. */
(function(w,d){'use strict';
var api={version:'0.2.1',normalized:0,warnings:[]};w.CodeCartBS5Compat=api;
function warn(s){if(api.warnings.indexOf(s)<0){api.warnings.push(s);if(w.console)w.console.warn('[CodeCart BS5] '+s);}}
if(!w.bootstrap||!w.bootstrap.Modal){warn('Load Bootstrap 5 bundle before compatibility JS');return;}
var bs=w.bootstrap;d.documentElement.classList.add('ccp-bs5-poc');
var mapping={'data-target':'data-bs-target','data-dismiss':'data-bs-dismiss','data-parent':'data-bs-parent','data-placement':'data-bs-placement','data-container':'data-bs-container','data-trigger':'data-bs-trigger','data-html':'data-bs-html','data-delay':'data-bs-delay','data-ride':'data-bs-ride','data-slide':'data-bs-slide','data-slide-to':'data-bs-slide-to','data-interval':'data-bs-interval'};
var known={modal:1,dropdown:1,collapse:1,tab:1,pill:1,tooltip:1,popover:1,button:1,offcanvas:1};
var selector='[data-toggle],[data-dismiss],[data-target],[data-parent],[data-placement],[data-container],[data-trigger],[data-html],[data-delay],[data-ride],[data-slide],[data-slide-to],[data-interval],[data-original-title],.dropdown-menu>li>a,.pagination>li>a,.pagination>li>span,.nav-tabs>li>a,.nav-pills>li>a,.collapse.in,.modal.in';
function normalize(el){
 if(!el||!el.matches)return;
 var old=el.getAttribute('data-toggle');
 if(old&&known[old]&&!el.hasAttribute('data-bs-toggle')){el.setAttribute('data-bs-toggle',old);api.normalized++;}
 if(old!=='buttons')Object.keys(mapping).forEach(function(k){if(el.hasAttribute(k)&&!el.hasAttribute(mapping[k])){el.setAttribute(mapping[k],el.getAttribute(k));api.normalized++;}});
 if(el.hasAttribute('data-original-title')&&!el.hasAttribute('title'))el.setAttribute('title',el.getAttribute('data-original-title'));
 if(el.matches('.dropdown-menu>li>a'))el.classList.add('dropdown-item');
 if(el.matches('.pagination>li>a,.pagination>li>span'))el.classList.add('page-link');
 if(el.matches('.nav-tabs>li>a,.nav-pills>li>a')){el.classList.add('nav-link');if(el.parentElement&&el.parentElement.classList.contains('active'))el.classList.add('active');}
 if(el.classList.contains('collapse')&&el.classList.contains('in'))el.classList.add('show');
 if(el.classList.contains('modal')&&el.classList.contains('in'))el.classList.add('show');
}
function normalizeTree(root){if(!root)return;if(root.nodeType===1&&root.matches(selector))normalize(root);if(root.querySelectorAll)root.querySelectorAll(selector).forEach(normalize);}
api.normalize=normalizeTree;
var names={modal:'Modal',dropdown:'Dropdown',collapse:'Collapse',tab:'Tab',tooltip:'Tooltip',popover:'Popover',alert:'Alert',carousel:'Carousel'};
function invoke(name,el,arg){
 var C=bs[names[name]];if(!C)return;
 var options=arg&&typeof arg==='object'?Object.assign({},arg):{};
 if(name==='modal')delete options.show;
 if(name==='collapse')delete options.toggle;
 if(options.container&&options.container.jquery)options.container=options.container[0];
 var instance=C.getOrCreateInstance(el,options),method=typeof arg==='string'?arg:null;
 if(method==='destroy')method='dispose';
 if(method){if(typeof instance[method]==='function'){instance[method]();return;}warn('Unsupported '+name+': '+method);return;}
 if(name==='modal'&&arg!==false&&(!arg||typeof arg!=='object'||arg.show!==false))instance.show();
 else if(name==='collapse'&&(!arg||typeof arg!=='object'||arg.toggle!==false))instance.toggle();
 else if(name==='carousel'&&typeof arg==='number')instance.to(arg);
}
function bridge(){
 var $=w.jQuery;if(!$||!$.fn){warn('jQuery is required for legacy plugin calls');return;}
 Object.keys(names).forEach(function(name){$.fn[name]=function(arg){return this.each(function(){invoke(name,this,arg);});};$.fn[name].Constructor=bs[names[name]];});
 $.fn.button=function(mode){return this.each(function(){var b=$(this);
  if(mode==='loading'){if(b.data('ccpOriginalHtml')===undefined)b.data('ccpOriginalHtml',b.html());b.text(b.attr('data-loading-text')||'Loading...').prop('disabled',true).addClass('disabled');}
  else if(mode==='reset'){var original=b.data('ccpOriginalHtml');if(original!==undefined)b.html(original);b.removeData('ccpOriginalHtml').prop('disabled',false).removeClass('disabled');}
  else if(mode==='toggle'){var a=this.classList.toggle('active');this.setAttribute('aria-pressed',a?'true':'false');}
 });};$.fn.button.Constructor=bs.Button;
}
api.installJqueryBridge=bridge;bridge();
d.addEventListener('shown.bs.tab',function(ev){var e=ev.target;if(!e||!e.closest)return;var ul=e.closest('.nav-tabs,.nav-pills');if(!ul)return;ul.querySelectorAll('li.active').forEach(function(li){li.classList.remove('active');});if(e.parentElement&&e.parentElement.tagName==='LI')e.parentElement.classList.add('active');});
d.addEventListener('change',function(ev){var input=ev.target;if(!input||!input.matches||!input.matches('input[type="radio"],input[type="checkbox"]'))return;var g=input.closest('[data-toggle="buttons"]');if(g)g.querySelectorAll('label.btn').forEach(function(label){var el=label.querySelector('input[type="radio"],input[type="checkbox"]');if(el)label.classList.toggle('active',el.checked);});});
var observer;function start(){normalizeTree(d);if(w.MutationObserver){observer=new MutationObserver(function(list){list.forEach(function(record){record.addedNodes.forEach(function(node){if(node.nodeType===1)normalizeTree(node);});});});observer.observe(d.documentElement,{childList:true,subtree:true});}bridge();}
if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',start);else start();
api.stop=function(){if(observer)observer.disconnect();};
api.report=function(){return{version:api.version,normalized:api.normalized,warnings:api.warnings.slice()};};
})(window,document);
